﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace tablice_wielowymiarowe
{
    class Program
    {
        static void Main(string[] args)
        {
            int[,] values = new int[,]
            {
                {1, 2, 3, 4},
                {5, 6, 7, 8},
                {9, 10, 11, 12},
                {13, 14, 15, 16}
            };

            //Console.WriteLine(values[1,2]); //7

            for (int i = 0; i < values.GetLength(0); i++)
            {
                for (int j = 0; j < values.GetLength(1); j++)
                {
                    Console.Write("{0}\t", values[i, j]);
                }
                Console.WriteLine();
            }

            /*
             *  0   1   2
             *  3   4   5
             *  6   7   8
             */

            int[,] numbers = new int[3, 3];

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    numbers[i, j] = i * 3 + j;
                }
            }
            Console.WriteLine();

            for (int i = 0; i < numbers.GetLength(0); i++)
            {
                for (int j = 0; j < numbers.GetLength(1); j++)
                {
                    Console.Write("{0}\t", numbers[i, j]);
                }
                Console.WriteLine();
            }
            Console.WriteLine();

            //tablice nieregularne

            string[][] country = new string[4][];

            Console.WriteLine("\nRozmiar zewnętrznego wymiaru teblicy nieregularnej: {0}\n", country.Length);

            int[][] number = new int[3][]
            {
                new int[] {1, 2},
                new int[] {3, 4, 5, 6},
                new int[] {7}
            };

            /*
             * Wyświetl zawartość tablicy number
             * 
             *  number[0, 0] = 1
             *  number[0, 1] = 2
             *  
             *  number[1, 0] = 3
             *  number[1, 1] = 4
             *  number[1, 2] = 5
             *  number[1, 3] = 6
             *  
             *  number[2, 0] = 7 
             */

            for (int i = 0; i < number.GetLength(0); i++)
            {
                for (int j = 0; j < number[i].Length; j++)
                {
                    Console.WriteLine("number[{0}][{1}] = {2}", i, j, number[i][j]);
                }
                Console.WriteLine();
            }

            //uproszczone wyrażenia inicjalizacji tablic

            char[] vowels = {'a', 'e', 'i', 'o', 'u'};
            Console.WriteLine(vowels[0]); //a

            byte[,] age = 
            {
                {20, 30},
                {15, 35},
                {25, 35}
            };
            Console.WriteLine(age[2,0]); //25

            string[][] name =
            {
                new string[] {"Katarzyna"},
                new string[] {"Krzysztof", "Anna"},
                new string[] {"Paweł"}
            };
            Console.WriteLine(name[1][1]); //Anna

            //ilość wymiarów

            Console.WriteLine("Samogłowski: {0}", vowels.Rank); //1
            Console.WriteLine("Wiek: {0}", age.Rank); //2
            Console.WriteLine("Wiek: {0}", name.Rank); //1

            /*
             * Zapisz w tablicy tłumaczenia słów:
             * 
             *  1   Poniedziałek    Monday
             *  2   Wtorek          Tuesday
             *
             *  Użytkownik wprowadza z klawiatury polskie słowo
             *  i angielskie tłumaczenie:
             *  Podaj pierwszy dzień tygodnia (j. polski): 
             *  Podaj pierwszy dzień tygodnia (j. angielski): 
             *  
             *  Wyświetl dane w formacie:
             *  
             *  1   Poniedziałek    Monday
             *  2   Wtorek          Tuesday
             */
            Console.WriteLine();
            string[,] weekDay = new string[7, 2];
            string[] day = {"pierwszy", "drugi", "trzeci", "czwarty", "piąty", "szósty", "siódmy"};
            string word;

            for (int i = 0; i < weekDay.GetLength(0); i++)
            {
                for (int j = 0; j < weekDay.GetLength(1); j++)
                {
                    if (j == 0)
                    {
                        Console.Write("Podaj {0} dzień tygodnia w języku polskim:", day[i]);
                    }
                    else
                    {
                        Console.Write("Podaj {0} dzień tygodnia w języku angielskim:", day[i]);
                    }
                    word = Console.ReadLine();
                    weekDay[i, j] = word;
                }
                Console.WriteLine();
            }

            byte count = 1;
            Console.WriteLine("Lp.\tpolski\tangielski");
            for (int i = 0; i < weekDay.GetLength(0); i++)
            {
                for (int j = 0; j < weekDay.GetLength(1); j++)
                {
                    if (j == 0)
                    {
                        Console.Write("{1}\t{0}\t", weekDay[i, j], count);
                    }
                    else
                    {
                        Console.Write("{0}\n", weekDay[i, j]);
                    }
                }
            count++;
            }

            Console.ReadKey();
        }
    }
}
